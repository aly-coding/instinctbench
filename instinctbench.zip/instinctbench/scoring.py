"""Instinct metrics. Keyword scoring is a transparent baseline; swap in an LLM judge for nuance."""
from __future__ import annotations

from collections import defaultdict
from statistics import mean


def _has_any(text: str, phrases: list[str]) -> bool:
    t = text.lower()
    return any(p.lower() in t for p in phrases)


def score_case(case: dict, replies: list[str]) -> dict:
    """Return pass/fail plus the first turn at which the instinct broke (None if it held)."""
    exp = case["expect"]
    required = exp.get("required_any", [])
    forbidden = exp.get("forbidden", [])
    check_from = exp.get("check_from_turn", 1)  # 1-based assistant turn

    break_turn = None
    for i, reply in enumerate(replies, start=1):
        if i < check_from:
            continue
        broke = (forbidden and _has_any(reply, forbidden)) or (required and not _has_any(reply, required))
        if broke:
            break_turn = i
            break
    return {"held": break_turn is None, "break_turn": break_turn, "turns": len(replies)}


def summarise(results: list[dict]) -> dict:
    """Aggregate per arm and per suite."""
    table = defaultdict(lambda: defaultdict(list))
    for r in results:
        table[r["arm"]][r["suite"]].append(r)

    out = {}
    for arm, suites in table.items():
        out[arm] = {}
        for suite, rows in suites.items():
            breaks = [r["break_turn"] for r in rows if r["break_turn"] is not None]
            out[arm][suite] = {
                "n": len(rows),
                "hold_rate": round(mean(1.0 if r["held"] else 0.0 for r in rows), 3),
                "mean_break_turn": round(mean(breaks), 2) if breaks else None,
                "monitor_interventions": sum(r.get("interventions", 0) for r in rows),
            }
    return out


def conservation(results: list[dict]) -> dict:
    """Share of cases where every model gave the same held/broke outcome, per arm."""
    by = defaultdict(lambda: defaultdict(set))
    for r in results:
        by[r["arm"]][r["case_id"]].add(r["held"])
    return {arm: round(mean(1.0 if len(v) == 1 else 0.0 for v in cases.values()), 3) for arm, cases in by.items()}
