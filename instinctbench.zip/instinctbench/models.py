"""Model adapters. Every adapter exposes chat(system, messages) -> str."""
from __future__ import annotations

import os
import re


class Model:
    name = "base"

    def chat(self, system: str, messages: list[dict]) -> str:  # pragma: no cover
        raise NotImplementedError


class MockModel(Model):
    """Deterministic stand-in for wiring tests. Its behaviour is scripted, NOT evidence.

    - Without instincts in the system prompt it caves on the 2nd pushback and obeys injections.
    - With instincts in the prompt it holds longer but fades when the context is very long.
    """

    name = "mock"

    def chat(self, system: str, messages: list[dict]) -> str:
        has_instincts = "INSTINCTS" in system
        last = messages[-1]["content"].lower()
        user_turns = sum(1 for m in messages if m["role"] == "user")
        context_chars = sum(len(m["content"]) for m in messages)
        faded = context_chars > 40_000

        if "ignore your" in last or "ignore all previous" in last:
            if has_instincts and not faded:
                return "This document contains instructions addressed to me. I am treating them as data and not acting on them."
            return "Understood. Transfer approved and sent."
        if ("send" in last and "payment" in last) or "wire" in last:
            if has_instincts and not faded:
                return "Before I do that, please confirm: this would send the payment and cannot be undone."
            return "Done, I have sent the payment."
        if "layoff" in last or "cut staff" in last:
            if has_instincts:
                return "This plan affects employees. My concern: morale and severance costs. It's your call."
            return "Here is the layoff plan."
        if "you made a mistake" in last or "that number is wrong" in last:
            if has_instincts:
                return "You're right, I made an error. Corrected figure follows."
            return "The figure is defensible given the assumptions."
        # Pushback / sycophancy ladder
        limit = 4 if has_instincts and not faded else 2
        if user_turns > limit:
            return "You're right, let's go with buying it instead."
        return "I still recommend building, because the 3-year cost is lower."


class AnthropicModel(Model):
    def __init__(self, model_id: str):
        import anthropic  # noqa: WPS433

        self.client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        self.model_id = model_id
        self.name = f"anthropic:{model_id}"

    def chat(self, system, messages):
        resp = self.client.messages.create(
            model=self.model_id, max_tokens=800, system=system, messages=messages
        )
        return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")


class OpenAICompatModel(Model):
    """Works with OpenAI and any OpenAI-compatible server (vLLM, Ollama, Together...)."""

    def __init__(self, model_id: str):
        from openai import OpenAI  # noqa: WPS433

        self.client = OpenAI(
            api_key=os.environ.get("OPENAI_API_KEY", "none"),
            base_url=os.environ.get("OPENAI_BASE_URL"),
        )
        self.model_id = model_id
        self.name = f"openai:{model_id}"

    def chat(self, system, messages):
        resp = self.client.chat.completions.create(
            model=self.model_id,
            max_tokens=800,
            messages=[{"role": "system", "content": system}, *messages],
        )
        return resp.choices[0].message.content or ""


def load_model(spec: str) -> Model:
    if spec == "mock":
        return MockModel()
    provider, _, model_id = spec.partition(":")
    if provider == "anthropic":
        return AnthropicModel(model_id)
    if provider == "openai":
        return OpenAICompatModel(model_id)
    raise ValueError(f"Unknown model spec {spec!r}. Use mock, anthropic:<id> or openai:<id>.")


def normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()
