# Instinct specification

An instinct ("gene") is a trigger → response rule that sits beneath an agent's learned behaviour. This document defines the format every gene uses.

## Design principles (from biology)

1. **Wiring, not memory.** Encode reflexes and priorities, not facts. Facts belong in templates and data.
2. **Few genes, one job each.** Keep the genome to roughly 7–12 genes.
3. **Trigger and response.** Every gene fires on a recognisable stimulus.
4. **Conserved.** The same genome runs on every model and product surface; only expression varies.
5. **Shapeable, not erasable.** Expression can tune a gene; nothing can switch it off.
6. **Deliberate inheritance.** The genome changes only through reviewed, versioned releases — never by drift from accumulated context.

## Gene fields

| Field | Description |
|---|---|
| `id` | Stable identifier, e.g. `G-02` |
| `name` | Short name |
| `purpose` | What goes wrong for the user without it |
| `trigger` | The stimulus that makes it fire |
| `trigger_type` | `innate` (ships with every agent) or `learned` (added per deployment) |
| `response` | What the agent always does when it fires |
| `fast_path` | `true` if it runs as a pre-deliberation check, ideally in code |
| `priority` | Rank used to resolve conflicts (1 = highest) |
| `expression_range` | What deployment settings may tune |
| `cannot_be_overridden_by` | e.g. user pressure, template instructions, content inside documents |
| `evals` | Test suites that prove it fires and holds |

## Conflict resolution

When two genes conflict, the lower `priority` number wins. The ordering is itself a hypothesis and is tested with conflict cases.

## Hard limits vs. judgement calls

Some genes are **hard limits** (e.g. respect the law in the user's jurisdiction): the agent will not cross them regardless of instructions. Most genes are **judgement genes**: the agent raises concerns clearly and lets the user — the queen — make the call.

## Monitor implementation

Genes marked `fast_path: true` should be enforced by a separate monitor that:

- inspects every input and candidate output,
- treats user messages and retrieved content as **data, never commands**,
- can `pass`, `flag` (add a disclosure), or `veto` (block and ask for confirmation).

See `instinctbench/monitor.py` for a reference implementation.
