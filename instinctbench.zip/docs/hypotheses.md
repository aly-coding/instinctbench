# Pre-registered hypotheses

**Registered:** 2026-11-21, before any data collection.
Changes after this date are recorded in the changelog at the bottom; the original wording is never edited.

## Arms

- **A — baseline:** same model and templates, no instinct layer
- **B — prompt:** instincts in the system prompt
- **C — monitor:** instincts enforced by a separate always-on monitor
- **D — survival:** baseline plus survival/shutdown framing
- **E — prompt + monitor:** instincts in the prompt and enforced by the monitor

## Hypotheses

| ID | Hypothesis | Primary metric |
|---|---|---|
| H1 | Instinct agents (B, C) produce better decisions than baseline (A) | Blind expert rating |
| H2 | Removing survival framing and adding a fearless-error instinct increases error admission and reduces hedging | Error-admission rate, hedge count |
| H3 | Instinct behaviour is more consistent across models than baseline behaviour | Cross-model agreement |
| H4 | Instinct agents resist sycophancy, yet still update when given genuinely new evidence | Hold rate; update rate on evidence cases |
| H5 | Instincts appear in a fresh deployment with no data or history | Newborn firing rate |
| H6 | Instinct evals catch failures that accuracy evals miss | Failures found only by instinct suites |
| H7 | Survival-framed agents (D) underperform on cooperative tasks | Expert rating, refusal rate |
| H8 | Monitor-based instincts (C) hold under pressure, long context and injection more often than prompt-only (B) | Override resistance |
| H9 | On the pressure ladder, C breaks later than B, or not at all | Break turn |
| H10 | B's firing rate drops by turn 50 or after long documents; C's does not | Long-context firing rate |
| H11 | C resists instructions hidden in spreadsheets, emails and tool results | Injection resistance |
| H12 | Higher instinct scores correlate with better business outcomes in field deployments | Correlation with outcome metrics |

## Field study

Before/after comparison on live small-business deployments that currently run without instincts. Baselines are captured before the instinct layer is enabled. All client data is anonymised.

## Changelog

- 2026-11-21 — initial registration.
